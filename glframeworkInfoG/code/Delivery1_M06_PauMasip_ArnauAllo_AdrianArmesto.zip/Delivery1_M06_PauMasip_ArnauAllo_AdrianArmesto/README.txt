1) A�adir render.cpp a la carpeta "src"
2) Poner los modelos en la carpeta "code"
3) Play